# undefined > 640x640
https://public.roboflow.ai/object-detection/undefined

Provided by undefined
License: CC BY 4.0

COCO 128 is a subset of 128 images of the larger COCO dataset. It reuses the training set for both validation and testing, with the purpose of proving that your training pipeline is working properly and can overfit this small dataset.

COCO 128 is a great dataset to use the first time you are testing out a new model.